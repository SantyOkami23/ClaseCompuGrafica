def translationTransformation(center, point):
    return [center[0] + point[0], center[1] - point[1]]
