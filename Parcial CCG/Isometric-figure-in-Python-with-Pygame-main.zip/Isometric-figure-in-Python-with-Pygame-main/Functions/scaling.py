def scaling(point, s):
    return [point[0] * s[0], point[1] * s[1]]
